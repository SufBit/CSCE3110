WA.cpp read from city.name and flight.txt and intialize a
adjacency matrix based graph representaion of the flight
information.  It associates each city with an integer as
its ID and prints out the flight information from each city 
to other cities using the IDs assigned.

To compile:
  g++ WA.cpp

To run:
  type "./a.out"
